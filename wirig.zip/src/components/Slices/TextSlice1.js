import * as React from "react"
import { Row } from 'react-flexbox-grid';
import { graphql } from "gatsby"
import { PrismicRichText } from "@prismicio/react"


const TextSlice1 = ({ slice }) => {
    return (
        <Row>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam hendrerit ipsum vel ligula tempus condimentum. Nunc in efficitununc. Nulla facilisi. Quisque sit amet leo lorem. Aliquam Quisque nibh ex, semper sit amet ornare vel, porttitor non lorem. Nam et purus tortor. Aenean rutrum nec eros non sagittis. Integer quis magna vitae tortor.</p>
        </Row>

    )
  }

  export default TextSlice1
