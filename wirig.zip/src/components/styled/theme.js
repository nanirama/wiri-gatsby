export const theme = {
  colors: {
    green: "#08b689",
    blue: "#4478db",
    black: "#303030",
  },
}
